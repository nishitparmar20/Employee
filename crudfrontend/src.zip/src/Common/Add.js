import { useState } from "react";
import "../add.css";
import Sidebar from "../Common/Sidebar";

function Addgpt() {
  let [addemp, SetEmp] = useState({
    username:"",
    email:"",
    phone:"",
    dob:"",
    gender:"",
    position:"",
    department:"",
    doj:"",
    address:"",
    profile:"",
  });

  function HandleInputChange(e) {
    let {name , value} = e.target;
    SetEmp((prev)=>({
      ...prev,
      [name]:value ,
    }));
  } 
}

  async function HandleSubmit(e) {
    e.preventDefault();
    
    try {
      await axios.post("").then((response)=>{
        console.log(response);
        
      })
    }
  
  }
  
  return (
    <>
      <div>
        <div className="d-flex">
          {/* Sidebar */}
          <Sidebar />

          {/* Main Content */}
          <div className="content">
            <div className="form-container">
              <h2>Add Employee</h2>
              <form method="post" action="/save_employee">
                <div className="form-group">
                  <label htmlFor="name">Full Name</label>
                  <input
                    type="text"
                    className="form-control"
                    name="name"
                    id="name"
                    required
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="email">Email Address</label>
                  <input
                    type="email"
                    className="form-control"
                    name="email"
                    id="email"
                    required
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="phone">Phone Number</label>
                  <input
                    type="tel"
                    className="form-control"
                    name="phone"
                    id="phone"
                    required
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="dob">Date of Birth</label>
                  <input
                    type="date"
                    className="form-control"
                    name="dob"
                    id="dob"
                  />
                </div>

                <div className="form-group">
                  <label>Gender</label>
                  <br />
                  <div>
                    <input type="radio" name="gender" value="Male" id="male" />
                    <label htmlFor="male"> Male </label>
                    &nbsp;&nbsp;
                    <input
                      type="radio"
                      name="gender"
                      value="Female"
                      id="female"
                    />
                    <label htmlFor="female"> Female </label>
                    &nbsp;&nbsp;
                    <input
                      type="radio"
                      name="gender"
                      value="Other"
                      id="other"
                    />
                    <label htmlFor="other"> Other </label>
                  </div>
                </div>

                <div className="form-group">
                  <label htmlFor="position">Position</label>
                  <input
                    type="text"
                    className="form-control"
                    name="position"
                    id="position"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="department">Department</label>
                  <select
                    className="form-control"
                    name="department"
                    id="department"
                  >
                    <option value="">Select Department</option>
                    <option value="HR">HR</option>
                    <option value="Development">Development</option>
                    <option value="Sales">Sales</option>
                    <option value="Marketing">Marketing</option>
                  </select>
                </div>

                <div className="form-group">
                  <label htmlFor="joining_date">Joining Date</label>
                  <input
                    type="date"
                    className="form-control"
                    name="joining_date"
                    id="joining_date"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="address">Address</label>
                  <textarea
                    className="form-control"
                    name="address"
                    id="address"
                    rows="3"
                  ></textarea>
                </div>

                <div className="form-group">
                  <label htmlFor="profile_pic">Profile Picture URL</label>
                  <input
                    type="url"
                    className="form-control"
                    name="profile_pic"
                    id="profile_pic"
                    placeholder="https://example.com/image.jpg"
                  />
                </div>

                <button type="submit" className="btn btn-primary">
                  Add Employee
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );


export default Add;
