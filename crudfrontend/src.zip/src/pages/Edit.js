import React, { useState } from "react";
import Sidebar from "../Common/Sidebar";
import { useLocation } from "react-router-dom";
import axios from "axios";
import {toast} from 'react-toastify'

function Edit() {
  let employeedata = useLocation().state;
  let [employee,setEmployee] = useState(employeedata);
  let handleInputChane =(e)=>{
      let {name , value} = e.target;
      setEmployee((prev)=>({
        ...prev,
        [name]:value,
      }));
  }
  console.log(employee);

  async function handleSubmit(e) {
    e.preventDefault();
    try {

      await axios.put("http://localhost:8000/edit",employee).then((res)=>{
        console.log(res.data);
        if(res.data.success) {
          toast.success("employee added successfully",{
            onclose : () =>{
              window.location.htmlFor = '/manage';
            }
          })
        }
      })

    }
    catch(err) {

    }

  }

  return (
    <>
      <div>
        <div className="d-flex">
          {/* Sidebar */}
          <Sidebar />

          {/* Main Content */}
          <div className="content">
            <div className="form-container">
              <h2>Edit Employee</h2>
              <form method="post" onSubmit={handleSubmit}>
                <input type="hidden" name="id" defaultValue={1} />

                <div className="form-group">
                  <label htmlFor="name">Full Name</label>
                  <input
                    type="text"
                    className="form-control"
                    name="name"
                    id="name"
                    defaultValue={employee.name}
                    onChange={handleInputChane}
                    required
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="email">Email Address</label>
                  <input
                    type="email"
                    className="form-control"
                    name="email"
                    id="email"
                    defaultValue={employee.email}
                    onChange={handleInputChane}
                    required
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="phone">Phone Number</label>
                  <input
                    type="tel"
                    className="form-control"
                    name="phone"
                    id="phone"
                    defaultValue={employee.phone}
                    onChange={handleInputChane}
                    required
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="dob">Date of Birth</label>
                  <input
                    type="date"
                    className="form-control"
                    name="dob"
                    id="dob"
                    onChange={handleInputChane}
                    defaultValue={
                      employee.dob
                    }
                  />
                </div>

                <div className="form-group">
                  <label>Gender</label>
                  <br />
                  <div>
                    <input
                      type="radio"
                      name="gender"
                      value="Male"
                      id="male"
                      defaultChecked
                    />
                    <label htmlFor="male"> Male </label>
                    &nbsp;&nbsp;
                    <input
                      type="radio"
                      name="gender"
                      value="Female"
                      id="female"
                    />
                    <label htmlFor="female"> Female </label>
                    &nbsp;&nbsp;
                    <input
                      type="radio"
                      name="gender"
                      value="Other"
                      id="other"
                    />
                    <label htmlFor="other"> Other </label>
                  </div>
                </div>

                <div className="form-group">
                  <label htmlFor="position">Position</label>
                  <input
                    type="text"
                    className="form-control"
                    name="position"
                    id="position"
                    defaultValue="Designer"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="department">Department</label>
                  <select
                    className="form-control"
                    name="department"
                    id="department"
                    defaultValue={employee.department}
                    onChange={handleInputChane}
                  >
                    <option value={employee.department}>{employee.department}</option>
                    <option value="HR">HR</option>
                    <option value="Development">Development</option>
                    <option value="Sales">Sales</option>
                    <option value="Marketing">Marketing</option>
                  </select>
                </div>

                <div className="form-group">
                  <label htmlFor="joining_date">Joining Date</label>
                  <input
                    type="date"
                    className="form-control"
                    name="joining_date"
                    id="joining_date"
                    defaultValue="2023-05-01"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="address">Address</label>
                  <textarea
                    className="form-control"
                    name="address"
                    id="address"
                    rows="3"
                    defaultValue="123 Main St, City"
                  ></textarea>
                </div>

                <div className="form-group">
                  <label htmlFor="profile_pic">Profile Picture URL</label>
                  <input
                    type="url"
                    className="form-control"
                    name="profile_pic"
                    id="profile_pic"
                    placeholder="https://example.com/image.jpg"
                    defaultValue="https://example.com/jane.jpg"
                  />
                </div>

                <button type="submit" className="btn btn-success">
                  Update Employee
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Edit;
