import "../manage.css";
import Sidebar from "../Common/Sidebar";
import { Link } from "react-router-dom";

function Manage() {
  return (
    <>
      <div>
        <div className="wrapper">
          {/* Sidebar */}
          <Sidebar />
          {/* Main Content */}
          <div className="content">
            <h2 className="mb-4">Manage Employees</h2>
            <div className="card mb-3">
              <div className="card-body">
                <h5 className="card-title">John Doe</h5>
                <p className="card-text">
                  Email: john@example.com
                  <br />
                  Position: Developer
                </p>
              </div>
              <div className="action-buttons p-3 ml-auto">
                <Link to="/edit" className="btn btn-sm btn-warning">
                  Edit
                </Link>
                <button
                  className="btn btn-sm btn-danger"
                  onClick="confirmDelete(1)"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Manage;
