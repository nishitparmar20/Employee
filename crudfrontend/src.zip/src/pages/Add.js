import { useState } from "react";
import axios from "axios";
// import "../add.css";
import Sidebar from "../Common/Sidebar";

function Add() {
  const [addemp, SetEmp] = useState({
    username: "",
    email: "",
    phone: "",
    dob: "",
    gender: "",
    position: "",
    department: "",
    joining_date: "",
    address: "",
    profile_pic: "",
  });

  function HandleInputChange(e) {
    let { name, value } = e.target;
    SetEmp((prev) => ({
      ...prev,
      [name]: value,
    }));
  }

  async function HandleSubmit(e) {
    e.preventDefault();

    try {
      const response = await axios.post("http://localhost:8000/add", addemp);
      console.log("Employee added:", response.data);

      alert("Employee Added Successfully!");

     // Reset form
      SetEmp({
        username: "",
        email: "",
        phone: "",
        dob: "",
        gender: "",
        position: "",
        department: "",
        joining_date: "",
        address: "",
        profile: "",
      });
    } catch (error) {
      console.error("Error:", error);
      alert("Failed to save employee!");
    }
  }

  return (
    <div className="d-flex">
      <Sidebar />

      <div className="content">
        <div className="form-container">
          <h2>Add Employee</h2>

          <form onSubmit={HandleSubmit}>
            <div className="form-group">
              <label>Full Name</label>
              <input
                type="text"
                className="form-control"
                name="username"
                value={addemp.username}
                onChange={HandleInputChange}
                required
              />
            </div>

            <div className="form-group">
              <label>Email Address</label>
              <input
                type="email"
                className="form-control"
                name="email"
                value={addemp.email}
                onChange={HandleInputChange}
                required
              />
            </div>

            <div className="form-group">
              <label>Phone Number</label>
              <input
                type="tel"
                className="form-control"
                name="phone"
                value={addemp.phone}
                onChange={HandleInputChange}
                required
              />
            </div>

            <div className="form-group">
              <label>Date of Birth</label>
              <input
                type="date"
                className="form-control"
                name="dob"
                value={addemp.dob}
                onChange={HandleInputChange}
              />
            </div>

            <div className="form-group">
              <label>Gender</label><br />
              <input
                type="radio"
                name="gender"
                value="Male"
                checked={addemp.gender === "Male"}
                onChange={HandleInputChange}
              /> Male
              &nbsp;&nbsp;
              <input
                type="radio"
                name="gender"
                value="Female"
                checked={addemp.gender === "Female"}
                onChange={HandleInputChange}
              /> Female
              &nbsp;&nbsp;
              <input
                type="radio"
                name="gender"
                value="Other"
                checked={addemp.gender === "Other"}
                onChange={HandleInputChange}
              /> Other
            </div>

            <div className="form-group">
              <label>Position</label>
              <input
                type="text"
                className="form-control"
                name="position"
                value={addemp.position}
                onChange={HandleInputChange}
              />
            </div>

            <div className="form-group">
              <label>Department</label>
              <select
                className="form-control"
                name="department"
                value={addemp.department}
                onChange={HandleInputChange}
              >
                <option value="">Select Department</option>
                <option value="HR">HR</option>
                <option value="Development">Development</option>
                <option value="Sales">Sales</option>
                <option value="Marketing">Marketing</option>
              </select>
            </div>

            <div className="form-group">
              <label>Joining Date</label>
              <input
                type="date"
                className="form-control"
                name="joining_date"
                value={addemp.joining_date}
                onChange={HandleInputChange}
              />
            </div>

            <div className="form-group">
              <label>Address</label>
              <textarea
                className="form-control"
                name="address"
                value={addemp.address}
                onChange={HandleInputChange}
              ></textarea>
            </div>

            <div className="form-group">
              <label>Profile Picture URL</label>
              <input
                type="url"
                className="form-control"
                name="profile"
                value={addemp.profile}
                onChange={HandleInputChange}
              />
            </div>

            <button type="submit" className="btn btn-primary">
              Add Employee
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Add;
