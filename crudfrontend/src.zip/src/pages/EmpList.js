import '../index.css';
import Sidebar from "../Common/Sidebar";
import axios, {} from "axios"
import { useEffect, useState } from 'react';

function EmpList() {
    let [Emp,SetEmp] = useState([]);
    useEffect(()=>{
      axios.get("http://localhost:8000/employees").then((response)=>{
        SetEmp(response.data.employees);
      });
    },[]);
  return (
    <div>
      <div className="wrapper">
        {/* Sidebar */}
        <Sidebar/>
        {/* Main Content */}
        <div className="content">
          <h2 className="mb-4">All Employees</h2>
          {
            Emp.map((value)=>{
              return(
                <>
                <div className="card">
            <div className="card-body">
              <h5 className="card-title">{value.username}</h5>
              <p className="card-text">
                {value.email}
                <br />
                {value.position}
              </p>
            </div>
          </div>
                </>
              )
            })
          }
          
        </div>
      </div>
    </div>
  );
}

export default EmpList;
